package com.managesystem.fragment.phoneBooke;

import com.managesystem.R;

/**
 * Created by Administrator on 2016/12/11.
 */
public class ReturnImages {
    public static int returnImage(String letters){
        if (letters.equals("A")){
            return R.drawable.a;
        }
        if (letters.equals("B")){
            return R.drawable.b;
        }
        if (letters.equals("C")){
            return R.drawable.c;
        }
        if (letters.equals("D")){
            return R.drawable.d;
        }
        if (letters.equals("E")){
            return R.drawable.e;
        }
        if (letters.equals("F")){
            return R.drawable.f;
        }
        if (letters.equals("G")){
            return R.drawable.g;
        }if (letters.equals("H")){
            return R.drawable.h;
        }if (letters.equals("I")){
            return R.drawable.i;
        }if (letters.equals("J")){
            return R.drawable.j;
        }if (letters.equals("K")){
            return R.drawable.k;
        }if (letters.equals("L")){
            return R.drawable.l;
        }
        if (letters.equals("M")){
            return R.drawable.m;
        }
        if (letters.equals("O")){
            return R.drawable.o;
        }
        if (letters.equals("P")){
            return R.drawable.p;
        }
        if (letters.equals("Q")){
            return R.drawable.q;
        }
        if (letters.equals("R")){
            return R.drawable.r;
        }
        if (letters.equals("S")){
            return R.drawable.s;
        }
        if (letters.equals("T")){
            return R.drawable.t;
        }
        if (letters.equals("U")){
            return R.drawable.u;
        }
        if (letters.equals("V")){
            return R.drawable.v;
        }
        if (letters.equals("W")){
            return R.drawable.w;
        }
        if (letters.equals("X")){
            return R.drawable.x;
        }
        if (letters.equals("Y")){
            return R.drawable.y;
        }
        if (letters.equals("Z")){
            return R.drawable.z;
        }
        return 0;
    }
}
