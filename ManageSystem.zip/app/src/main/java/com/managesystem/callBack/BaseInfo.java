package com.managesystem.callBack;

/**
 * Created by Administrator on 2016/7/7.
 */
public class BaseInfo {
    public static int code = 0;
}
