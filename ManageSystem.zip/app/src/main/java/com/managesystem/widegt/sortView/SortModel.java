package com.managesystem.widegt.sortView;

public class SortModel {

	private String sortLetters;  //首字符
	public String getSortLetters() {
		return sortLetters;
	}
	public void setSortLetters(String sortLetters) {
		this.sortLetters = sortLetters;
	}
}
