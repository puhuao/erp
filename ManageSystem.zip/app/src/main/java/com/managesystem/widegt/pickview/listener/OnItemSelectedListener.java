package com.managesystem.widegt.pickview.listener;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
