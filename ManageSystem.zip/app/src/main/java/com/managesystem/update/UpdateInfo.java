package com.managesystem.update;

/**
 * Created by Administrator on 2016/7/31.
 */
public class UpdateInfo {
    public String version;
    public String url;
    public String desc;
}
