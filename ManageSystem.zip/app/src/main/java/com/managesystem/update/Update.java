package com.managesystem.update;


/**
 * 应用程序更新实体类
 * 
 * @author wanglin(linw@jumei.com) 2013-1-30下午2:31:22
 */
public class Update {
    
    public final static String UTF8 = "UTF-8";
    
    public String vcode ;
    
    public String vname ;
    
    public String url;
    
    public String note;
    
    public String date;
    
    
}
