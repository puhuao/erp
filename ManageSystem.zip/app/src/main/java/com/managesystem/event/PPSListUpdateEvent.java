package com.managesystem.event;

/**
 * Created by Administrator on 2016/11/24.
 */
public class PPSListUpdateEvent {
}
