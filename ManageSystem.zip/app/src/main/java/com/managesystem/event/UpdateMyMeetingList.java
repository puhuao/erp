package com.managesystem.event;

/**
 * Created by Administrator on 2016/12/20.
 */
public class UpdateMyMeetingList {
}
