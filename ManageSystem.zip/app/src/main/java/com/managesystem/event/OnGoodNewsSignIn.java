package com.managesystem.event;

/**
 * Created by Administrator on 2016/12/22.
 */
public class OnGoodNewsSignIn {
}
