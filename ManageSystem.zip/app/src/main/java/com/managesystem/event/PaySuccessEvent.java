package com.managesystem.event;

/**
 * Created by Administrator on 2016/12/6.
 */
public class PaySuccessEvent {
}
