package com.managesystem.event;

/**
 * Created by Administrator on 2016/12/17.
 */
public class OnMSGNoticeEvent {
    public int number;

    public OnMSGNoticeEvent(int number) {
        this.number = number;
    }
}
