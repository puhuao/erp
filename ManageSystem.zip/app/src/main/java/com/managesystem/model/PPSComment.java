package com.managesystem.model;

/**
 * Created by Administrator on 2016/11/23.
 */
public class PPSComment {

    /**
     * content : 钱钱钱钱钱
     * name : mr
     * userId : xiaoti
     * topicId : 221f6ea215d1450096f0c3c72f561035
     * headPic : null
     * replyId : 1b66c16de02e4f479e93e8a8af5218d4
     * ctime : 2016-11-22 00:03
     */

    private String content;
    private String name;
    private String userId;
    private String topicId;
    private String headPic;
    private String replyId;
    private String ctime;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTopicId() {
        return topicId;
    }

    public void setTopicId(String topicId) {
        this.topicId = topicId;
    }

    public String getHeadPic() {
        return headPic;
    }

    public void setHeadPic(String headPic) {
        this.headPic = headPic;
    }

    public String getReplyId() {
        return replyId;
    }

    public void setReplyId(String replyId) {
        this.replyId = replyId;
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime;
    }
}
