package com.managesystem.model;

/**
 * Created by puhua on 2016/11/10.
 *
 * @
 */

public class MeetingRoomDetail {

    /**
     * startDate : 2016-11-12 03:36:16
     * status : 1
     * endDate : 2016-11-12 07:36:16
     * meetingroomName : 蓝布阁
     * ctime : null
     * departmentName : 运维
     * servicetypeId : null
     * infor :
     * area : China
     * floor : 1
     * meetingName : 123123123123
     * userId : a20b5f837d914b6aab55ae7cda89403c
     * name : Isaac
     * meetingId : f1bc81f70c214efc8f6e1e009465f72f
     * cphone :
     * meetingroomId : 231212
     * officeNo : 001
     */

    private String startDate;
    private int status;
    private String endDate;
    private String meetingroomName;
    private String ctime;
    private String departmentName;
    private String servicetypeId;
    private String infor;
    private String area;
    private String floor;
    private String meetingName;
    private String userId;
    private String name;
    private String meetingId;
    private String cphone;
    private String meetingroomId;
    private String officeNo;

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getMeetingroomName() {
        return meetingroomName;
    }

    public void setMeetingroomName(String meetingroomName) {
        this.meetingroomName = meetingroomName;
    }


    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getCtime() {
        return ctime;
    }

    public void setCtime(String ctime) {
        this.ctime = ctime;
    }

    public String getServicetypeId() {
        return servicetypeId;
    }

    public void setServicetypeId(String servicetypeId) {
        this.servicetypeId = servicetypeId;
    }

    public String getInfor() {
        return infor;
    }

    public void setInfor(String infor) {
        this.infor = infor;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getMeetingName() {
        return meetingName;
    }

    public void setMeetingName(String meetingName) {
        this.meetingName = meetingName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMeetingId() {
        return meetingId;
    }

    public void setMeetingId(String meetingId) {
        this.meetingId = meetingId;
    }

    public String getCphone() {
        return cphone;
    }

    public void setCphone(String cphone) {
        this.cphone = cphone;
    }

    public String getMeetingroomId() {
        return meetingroomId;
    }

    public void setMeetingroomId(String meetingroomId) {
        this.meetingroomId = meetingroomId;
    }

    public String getOfficeNo() {
        return officeNo;
    }

    public void setOfficeNo(String officeNo) {
        this.officeNo = officeNo;
    }
}
