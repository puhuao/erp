package com.managesystem.model;

/**
 * Created by Administrator on 2016/11/12.
 */
public class MeetingType {

    /**
     * servicetypeId : 2cb289f548e24c86b8381cbc28fa22ba
     * servicetypeName : 会议
     */

    private String servicetypeId;
    private String servicetypeName;

    public String getServicetypeId() {
        return servicetypeId;
    }

    public void setServicetypeId(String servicetypeId) {
        this.servicetypeId = servicetypeId;
    }

    public String getServicetypeName() {
        return servicetypeName;
    }

    public void setServicetypeName(String servicetypeName) {
        this.servicetypeName = servicetypeName;
    }
}
