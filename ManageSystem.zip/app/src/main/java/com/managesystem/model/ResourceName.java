package com.managesystem.model;

/**
 * Created by Administrator on 2016/11/20.
 */
public class ResourceName {

    /**
     * materialName : 打印机
     * materialTypeId : 7ce621ac050849cfb7e599866da6e38a
     * materialnameId : 528c902fd7ba46ed9aa3b943023bca5e
     */

    private String materialName;
    private String materialTypeId;
    private String materialnameId;

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getMaterialTypeId() {
        return materialTypeId;
    }

    public void setMaterialTypeId(String materialTypeId) {
        this.materialTypeId = materialTypeId;
    }

    public String getMaterialnameId() {
        return materialnameId;
    }

    public void setMaterialnameId(String materialnameId) {
        this.materialnameId = materialnameId;
    }
}
