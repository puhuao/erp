package com.managesystem.model;

/**
 * Created by Administrator on 2016/11/20.
 */
public class ResourceType {

    /**
     * materialTypeName : 易耗
     * materialtypeId : 0d88a798fca04ae68a83634a16765aaa
     */

    private String materialTypeName;
    private String materialtypeId;

    public String getMaterialTypeName() {
        return materialTypeName;
    }

    public void setMaterialTypeName(String materialTypeName) {
        this.materialTypeName = materialTypeName;
    }

    public String getMaterialtypeId() {
        return materialtypeId;
    }

    public void setMaterialtypeId(String materialtypeId) {
        this.materialtypeId = materialtypeId;
    }
}
