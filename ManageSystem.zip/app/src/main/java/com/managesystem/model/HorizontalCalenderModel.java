package com.managesystem.model;

import java.util.Calendar;

/**
 * Created by puhua on 2016/11/10.
 *
 * @
 */

public class HorizontalCalenderModel {
    public int month;
    public int name;
    public int weekDay;
    public String calendar;

}
