package com.wksc.framwork.baseui;

import com.wksc.framwork.baseui.fragment.CubeFragment;

public class FragmentParam {
    public CubeFragment from;
    public Class<?> cls;
    public Object data;

}
