package com.wksc.framwork.util;

public class AppDebug {
    public static boolean DEBUG_CACHE = false;
    public static boolean DEBUG_IMAGE = false;
    public static boolean DEBUG_REQUEST = false;

    // print lifecycle information by log tag "watching-app-lifecycle"
    public static boolean DEBUG_LIFE_CYCLE = false;

}
