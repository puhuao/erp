package com.wksc.framwork.zxing;

public class ZxingConfig {
	public static final int Zxing_Start_Decode = 0x300000;
	public static final int Zxing_Decode_Failed = 0x300001;
	public static final int Zxing_Decode_Succeeded = 0x300002;
	public static final int Zxing_Quit = 0x300003;
	public static final int Zxing_Restart_Decode = 0x300004;
	public static final int Zxing_Decode_Result = 0x300005;
	public static final int Zxing_Open_Result = 0x300006;
}
