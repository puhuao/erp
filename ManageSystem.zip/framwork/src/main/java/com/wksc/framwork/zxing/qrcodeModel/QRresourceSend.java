package com.wksc.framwork.zxing.qrcodeModel;

/**
 * Created by Administrator on 2016/11/21.
 */
public class QRresourceSend {

    /**
     * pStr : ?type=2&fromUserId=bfb4c1e7da17452398b16bc1e80ae615&materials[0].materialId=8691d5f422144848a834e8f86aae53fb&materials[0].serialNumber=fadaf
     */

    private String pStr;

    public String getPStr() {
        return pStr;
    }

    public void setPStr(String pStr) {
        this.pStr = pStr;
    }
}
