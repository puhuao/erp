package com.wksc.framwork.zxing.qrcodeModel;

/**
 * Created by Administrator on 2016/11/15.
 */
public class QRChecInModel {

    private String meetingId;
    private String type;

    public String getMeetingId() {
        return meetingId;
    }

    public void setMeetingId(String meetingId) {
        this.meetingId = meetingId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
