package com.wksc.framwork.platform.common;

/**
 * Created by Gou Zhuang <gouzhuang@gmail.com> on 2015-03-17.
 */
public interface Condition {
    public boolean evaluate();
}
