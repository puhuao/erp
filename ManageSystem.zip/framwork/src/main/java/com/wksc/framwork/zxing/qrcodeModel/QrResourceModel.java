package com.wksc.framwork.zxing.qrcodeModel;

/**
 * Created by Administrator on 2016/11/21.
 */
public class QrResourceModel {
    private String type;
    private QRresourceSend param;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public QRresourceSend getParam() {
        return param;
    }

    public void setParam(QRresourceSend param) {
        this.param = param;
    }
}
