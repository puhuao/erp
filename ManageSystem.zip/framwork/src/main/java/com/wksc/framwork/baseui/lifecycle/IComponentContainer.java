package com.wksc.framwork.baseui.lifecycle;


public interface IComponentContainer {

    public void addComponent(LifeCycleComponent component);
}
